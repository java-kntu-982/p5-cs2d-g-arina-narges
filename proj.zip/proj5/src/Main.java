import java.io.IOException;
/*
 * Main.java
 */

/**
 *
 *
 */
public class Main {

    /** Creates a new instance of Main */
    public Main()
    {

    }

    public static void main(String args[]) throws IOException
    {
        ClientGUI client=new ClientGUI();

    }

}
